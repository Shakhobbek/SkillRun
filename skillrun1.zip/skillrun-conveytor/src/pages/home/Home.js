import React,{Component} from 'react';
import './style.css';
class Home extends Component{
    render() {
        return (
            <div>
                <header>
                    <div className="menu" id="myHeader">
                        <div className="logo">
                            <img src="images/logo-1.png" alt="" />
                        </div>
                        <div className="searchbar">
                            <input type="text" placeholder="Search" />
                            <div className="icon">
                                <i className="fas fa-search" />
                            </div>
                        </div>
                        <div className="nav">
                            <ul>
                                <li><a href="index.html">HOME</a></li>
                                <li><a href="#">ABOUT</a></li>
                                <li><a href="#">COURSES</a></li>
                            </ul>
                        </div>
                        <div className="sign">
                            <button><a href="signup/index.html">SIGN Up</a></button>
                        </div>
                    </div>
                    <div className="hero">
                        <div className="quote-content">
                            <div className="quote">
                                <i className="fas fa-quote-left left" />
                                <h1 className="quote-text">An Investment in knowledge pays the best interest</h1>
                                <i className="fas fa-quote-right right" />
                            </div>
                            <div className="author-pic">
                                <img src="images/hero-3.jpg" alt="" />
                            </div>
                        </div>
                        <h2><i className="far fa-copyright" /> Benjamin Franklin</h2>
                    </div>
                </header>
                <footer>
                </footer>
            </div>
        );
    }
}export default Home;