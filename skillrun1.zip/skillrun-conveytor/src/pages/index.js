import React,{Component} from 'react';
import Home from "./home/Home";
import Signup from "./signUp/Signup";
import Step2 from "./signUp/Step2";
import Step3 from "./signUp/Step3";
import Step4 from "./signUp/Step4";
import Step5 from "./signUp/Step5";
import Step6 from "./signUp/Step6";
class Index extends Component{
    render() {
        return (
            <div>
                <Step6/>
            </div>
        );
    }
}export default Index;