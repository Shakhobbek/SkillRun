import React,{Component} from 'react';
import './style.css';
class Signup extends Component{
    render() {
        return (
            <div>
                <header>
                    <div className="logo">
                        <img src="../images/logo-2.png" alt="" />
                    </div>
                    <div className="login">
                        <p>Войти в существующий аккаунт <a href="#">Вход</a></p>
                    </div>
                </header>
                <section>
                    <div className="form-box">
                        <h2>Регистрация</h2>
                        <div className="social-icons">
                            <i className="fab fa-google google" />
                            <i className="fab fa-apple icloud" />
                        </div>
                        <div className="email">
                            <i className="fas fa-envelope" />
                            <input type="text" required placeholder="Введите Email" /><br />
                        </div>
                        <input type="submit" defaultValue="Продолжить" /><br />
                        <input type="checkbox" id="agreement" />
                        <label htmlFor="agreement">Я ознакомился и подтверждаю согласие с условиями <a href="#">пользовательского соглашения</a></label>
                    </div>
                    <div className="hero">
                        <img src="../images/undraw_Login_re_4vu2.svg" alt="" />
                    </div>
                </section>
                <div className="partners">
                    <h2>Наши Партнёры</h2>
                    <div className="logo-partners">
                        <img src="https://logobank.uz:8005/media/logos_png/IT_park-01.png" alt="" />
                        <img className="onemillion" src="https://uzbekcoders.uz/frontend/assets/images/uz.png" alt="" />
                        <img className="zoom" src="https://rocketgirlsolutions.com/wp-content/uploads/2020/03/zoom-logo-transparent-6.png" alt="" />
                        <img className="mitc" src="https://mitc.uz/img/logo.png" alt="" />
                        <img className="stat" src="https://stat.uz/images/uzstat.png" alt="" />
                    </div>
                </div>
                <footer>
                    <img src="../images/logo-2.png" alt="" className="logo" />
                    <div className="social-footer">
                        <i className="fab fa-instagram insta" />
                        <i className="fab fa-youtube tube" />
                        <i className="fab fa-twitter twitter" />
                    </div>
                    <div className="copyright">
                        <p><i className="far fa-copyright" />2020 Skillrun.Uz Все права защищены</p>
                    </div>
                </footer></div>
        );
    }
}export default Signup;