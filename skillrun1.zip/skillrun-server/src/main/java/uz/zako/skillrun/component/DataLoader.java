package uz.zako.skillrun.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import uz.zako.skillrun.entity.Role;
import uz.zako.skillrun.entity.User;
import uz.zako.skillrun.repository.RoleRepository;
import uz.zako.skillrun.service.UserService;


@Component
public class DataLoader implements CommandLineRunner {
 @Autowired
 private RoleRepository roleRepository;

 @Autowired
 private PasswordEncoder passwordEncoder;

 @Autowired
 private UserService userService;

    @Override
    public void run(String... args) throws Exception {
        Role roleAdmin=new Role(1l,"ROLE_ADMIN");
        Role roleUser=new Role(2l,"ROLE_USER");
        try{
            roleRepository.save(roleAdmin);
            roleRepository.save(roleUser);
        }catch (Exception e){
            System.out.println(e);
        }
        User user=new User();
        user.setUsername("admin");
        user.setEnabled(true);
        user.setBirthday("09-11-1999");
        user.setFirstname("Nurbek ");
        user.setLastname("Kholmurodov");
        user.setRoles(roleRepository.findAll());
        user.setPassword(passwordEncoder.encode("12345"));
     userService.save(user);
    }
}
