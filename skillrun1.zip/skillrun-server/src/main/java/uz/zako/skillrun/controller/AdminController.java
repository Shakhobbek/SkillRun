package uz.zako.skillrun.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import uz.zako.skillrun.entity.*;
import uz.zako.skillrun.payload.DistrictReq;
import uz.zako.skillrun.payload.LangLevelReq;
import uz.zako.skillrun.payload.SkillLevelReq;
import uz.zako.skillrun.payload.SkillSubCategoryReq;
import uz.zako.skillrun.service.*;

@RestController
@RequestMapping("/api/admin")
public class AdminController {
    @Autowired
    private DistrictService districtService;

    @Autowired
    private LangLevelService langLevelService;

    @Autowired
    private RegionService regionService;

    @Autowired
    private SkillCategoryService skillCategoryService;

    @Autowired
    private SkillLevelService skillLevelService;

    @Autowired
    private SkillSubCategoryService skillSubCategoryService;

    @PostMapping("/district/save")
    public District saveDistrict(@RequestBody DistrictReq districtReq){
        return districtService.save(districtReq);
    }

    @PutMapping("/district/edit/{id}")
    public District edit(@RequestBody DistrictReq districtReq,@PathVariable Long id){
        return districtService.edit(id, districtReq);
    }

    @PostMapping("/langlevel/save")
    public LangLevel saveLangLevel(@RequestBody LangLevelReq langLevelReq){
        return langLevelService.save(langLevelReq);
    }

    @PutMapping("/langlevel/edit/{id}")
    public LangLevel editLangLevel(@RequestBody LangLevelReq langLevelReq,@PathVariable Long id){
        return langLevelService.edit(id, langLevelReq);
    }

    @PostMapping("/region/save")
    public Region saveRegion(@RequestBody Region region){
        return regionService.save(region);
    }

    @PutMapping("/region/edit/{id}")
    public Region editRegion(@PathVariable Long id,@RequestBody Region region){
        return regionService.edit(id, region);
    }

    @PostMapping("/skillCategory/save")
    public SkillCategory skillCategorysave(@RequestBody SkillCategory skillCategory){
        return skillCategoryService.save(skillCategory);
    }

    @PutMapping("/skillCategory/edit/{id}")
    public SkillCategory skillCategoryEdit(@PathVariable Long id,@RequestBody SkillCategory skillCategory){
        return skillCategoryService.edit(id, skillCategory);
    }

    @PostMapping("/skillLevel/save")
    public SkillLevel skillLevelSave(@RequestBody SkillLevelReq skillLevelReq){
        return skillLevelService.save(skillLevelReq);
    }

    @PutMapping("/skillLevel/edit/{id}")
    public SkillLevel skillLevelEdit(@RequestBody SkillLevelReq req,@PathVariable Long id){
        return skillLevelService.edit(id, req);
    }

    @PostMapping("/skillSubCategory/save")
    public SkillSubCategory skillSubCategorySave(@RequestBody SkillSubCategoryReq req){
        return skillSubCategoryService.save(req);
    }

    @PutMapping("/skillSubCategory/edit/{id}")
    public SkillSubCategory skillSubCategoryEdit(@PathVariable Long id,@RequestBody SkillSubCategoryReq req){
        return skillSubCategoryService.edit(id, req);
    }



}
