package uz.zako.skillrun.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uz.zako.skillrun.entity.*;
import uz.zako.skillrun.model.JwtResponse;
import uz.zako.skillrun.payload.LoginReq;
import uz.zako.skillrun.service.*;

import java.util.List;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    @Autowired
    private UserService userService;

    @Autowired
    private DistrictService districtService;

    @Autowired
    private LangLevelService langLevelService;

    @Autowired
    private RegionService regionService;

    @Autowired
    private SkillCategoryService skillCategoryService;

    @Autowired
    private SkillLevelService skillLevelService;

    @Autowired
    private SkillSubCategoryService skillSubCategoryService;

    @PostMapping("/signin")
    public ResponseEntity<JwtResponse> authenticateUser(@RequestBody LoginReq loginRequest) {
       return userService.signin(loginRequest);
    }

  @GetMapping("/districts/{regionId}")
    public List<District> districtList(@PathVariable Long regionId){
        return districtService.findAllByRegionId(regionId);
  }

  @GetMapping("/langLevels/{langId}")
    public List<LangLevel> langLevels(@PathVariable Long langId){
        return langLevelService.findAllByLanguageId(langId);
  }

  @GetMapping("/regions")
    public List<Region> regions(){
        return regionService.findAll();
  }

  @GetMapping("/skillCategorys")
    public List<SkillCategory> skillCategories(){
        return skillCategoryService.findAll();
  }

  @GetMapping("/skillLevels/{skillSubCategoryId}")
    public List<SkillLevel> skillLevels(@PathVariable Long skillSubCategoryId){
        return skillLevelService.findAllBySkillSubCategorieId(skillSubCategoryId);
  }

  @GetMapping("/skillSubcategorys/{skillCategoryId}")
    public List<SkillSubCategory> skillSubCategories(@PathVariable Long skillCategoryId){
        return skillSubCategoryService.findAllBySkillCategoryId(skillCategoryId);
  }

}
