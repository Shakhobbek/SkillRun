package uz.zako.skillrun.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Experience {
@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

private String nameUz;
private String nameRu;
private String startDate;
private String endDate;

@ManyToOne(fetch = FetchType.LAZY)
    private Worker worker;

}
