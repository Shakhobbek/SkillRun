package uz.zako.skillrun.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class SkillSubCategory {
  @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

  private String nameUz;
  private String nameRu;

  @JsonIgnore
  @ManyToOne(fetch = FetchType.LAZY)
    private SkillCategory skillCategory;
}
