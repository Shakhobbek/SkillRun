package uz.zako.skillrun.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.HashMap;
import java.util.Map;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Worker extends User {

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    private District district;

    @ElementCollection
    @MapKeyColumn(name="language")
    @Column(name="language_level")
    @CollectionTable(name="language_level_language", joinColumns=@JoinColumn(name="worker_id"))
    Map<String, String> language_languageLevel = new HashMap<>();

    @ElementCollection
    @MapKeyColumn(name="skill_subcategory")
    @Column(name="skill_subcategory_level")
    @CollectionTable(name="woker_skillsubcategory", joinColumns=@JoinColumn(name="worker_id"))
    Map<String, String> skill_subcategory_level = new HashMap<>();

}
