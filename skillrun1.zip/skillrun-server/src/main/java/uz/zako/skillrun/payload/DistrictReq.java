package uz.zako.skillrun.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class DistrictReq {
    private String nameUz;
    private String nameRu;

    private Long regionId;
}
