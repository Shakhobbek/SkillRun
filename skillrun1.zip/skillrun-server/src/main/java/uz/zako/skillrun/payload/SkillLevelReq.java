package uz.zako.skillrun.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class SkillLevelReq {
    private String nameUz;
    private String nameRu;

    private List<Long> skillSubCategorieIds;
}
