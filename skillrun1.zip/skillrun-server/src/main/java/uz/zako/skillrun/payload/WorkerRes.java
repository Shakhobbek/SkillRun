package uz.zako.skillrun.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class WorkerRes {
     private Long id;

    private String email;

    private String password;

    private String firstname;

    private String lastname;

    private String birthday;

    private UUID photoAvatarId;

    private Long districtId;

    Map<String, String> language_languageLevel = new HashMap<>();

    Map<String, String> skill_subcategory = new HashMap<>();

}
