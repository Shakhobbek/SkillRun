package uz.zako.skillrun.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import uz.zako.skillrun.entity.District;

import java.util.List;

@Repository
public interface DistrictRepository  extends JpaRepository<District,Long> {
    public List<District> findAllByRegionId(Long regionId);
}
