package uz.zako.skillrun.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import uz.zako.skillrun.entity.Education;

import java.util.List;

@Repository
public interface EducationRepository  extends JpaRepository<Education,Long> {
    public List<Education> findAllByWorkerId(Long workerId);
}
