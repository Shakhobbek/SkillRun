package uz.zako.skillrun.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import uz.zako.skillrun.entity.Experience;

import java.util.List;

@Repository
public interface ExperienceRepository  extends JpaRepository<Experience,Long> {
  public List<Experience> findAllByWorkerId(Long id);
}
