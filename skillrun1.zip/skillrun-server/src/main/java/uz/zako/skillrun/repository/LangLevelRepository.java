package uz.zako.skillrun.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import uz.zako.skillrun.entity.LangLevel;

import java.util.List;

@Repository
public interface LangLevelRepository extends JpaRepository<LangLevel,Long> {
@Query(nativeQuery = true,value = "select ll.* from  lang_level  ll " +
        "inner join lang_level_languages lll " +
        "on ll.id=lll.lang_level_id where lll.languages_id=:lang_id")
    public List<LangLevel> findAllByLanguageId(@Param("lang_id")Long langId);
}
