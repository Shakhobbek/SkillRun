package uz.zako.skillrun.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import uz.zako.skillrun.entity.SkillLevel;

import java.util.List;

@Repository
public interface SkillLevelRepository  extends JpaRepository<SkillLevel,Long> {
@Query(nativeQuery = true,value = "select sl.* from skill_level sl  " +
        "inner join skill_level_skill_sub_categories sc " +
        "on sl.id=sc.skill_level_id where sc.skill_sub_categories_id=:sub_id")
    public List<SkillLevel> findAllBySkillSubCategorieId(@Param("sub_id") Long subCategorieId);
}
