package uz.zako.skillrun.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import uz.zako.skillrun.entity.Attachment;
import uz.zako.skillrun.model.Result;
import uz.zako.skillrun.repository.AttachmentRepository;

import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;


@Service
public class AttachmentService {

    @Autowired
    private AttachmentRepository attachmentRepository;
//    private final String uploadPath="D://Proekt/lms/lms-server/UploadFiles/";
    private final String uploadPath="UploadFiles/";

    public Attachment findById(UUID id){
        try{
            return attachmentRepository.findById(id).get();
        }catch (Exception e){
            return null;
        }
    }

    @Transactional
    public Attachment saveFileToServer(MultipartFile mpf, String filename, String parent) {
        Attachment attachment=null;
            Path path1=Paths.get(uploadPath+"/"+parent);
          path1=checkPackage(path1);
        System.out.println(path1.toFile().getAbsolutePath());
        try {
                 attachment = new Attachment();
                attachment.setName(parent+"/"+filename);
                attachment.setOriginalName(mpf.getOriginalFilename());
                attachment.setSize(mpf.getSize());
                attachment.setContentType(mpf.getContentType());
                String path=path1.toFile().getAbsolutePath()+"/"+filename+mpf.getOriginalFilename();
            System.out.println(path);
                File file=new File(path);
                mpf.transferTo(file);
                attachment = attachmentRepository.save(attachment);
            } catch (Exception e) {
                e.printStackTrace();
            }
        return attachment;
    }


    @Transactional(readOnly = true, propagation = Propagation.SUPPORTS)
    public ResponseEntity<InputStreamResource> downloadToServer(UUID id, HttpServletResponse response) throws IOException {
        Attachment attachment=attachmentRepository.findById(id).get();
        String path=uploadPath+attachment.getName()+attachment.getOriginalName();

        File file=new File(path);
        InputStreamResource resource = new InputStreamResource(new FileInputStream(file));
        HttpHeaders header = new HttpHeaders();
        header.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename="+attachment.getOriginalName());
        header.add("Cache-Control", "no-cache, no-store, must-revalidate");
        header.add("Pragma", "no-cache");
        header.add("Expires", "0");
        return ResponseEntity.ok()
                .headers(header)
                .contentLength(file.length())
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(resource);

    }
    public Result deleteFromServer(UUID id){
        try{
            Attachment attachment=attachmentRepository.findById(id).get();
            File file=new File(uploadPath+attachment.getName()+attachment.getOriginalName());
            if (file.delete()){
                attachmentRepository.deleteById(id);
                return new Result(true,"Successfull deleting file");
            }else {
                return new Result(false,"No deleting files");
            }
        }catch (Exception e){
            System.out.println(e);
            return new Result(false,"No deleting files");
        }
    }

    private Path checkPackage(Path file) {
        if (!file.toFile().exists())
            file.toFile().mkdirs();
        return file;
    }

}
