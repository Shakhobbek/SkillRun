package uz.zako.skillrun.service;

import uz.zako.skillrun.entity.District;
import uz.zako.skillrun.model.Result;
import uz.zako.skillrun.payload.DistrictReq;

import java.util.List;

public interface DistrictService {
    public District save(DistrictReq districtReq);
    public District edit(Long id,DistrictReq districtReq);

    public District findById(Long id);
    public List<District> findAllByRegionId(Long regionId);
    public Result delete(Long id);
}
