package uz.zako.skillrun.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.zako.skillrun.entity.District;
import uz.zako.skillrun.model.Result;
import uz.zako.skillrun.payload.DistrictReq;
import uz.zako.skillrun.repository.DistrictRepository;

import java.util.ArrayList;
import java.util.List;

@Service
public class DistrictServiceImpl implements DistrictService {
    @Autowired
    private DistrictRepository districtRepository;

    @Autowired
    private RegionService regionService;

    @Override
    public District save(DistrictReq districtReq) {
       try {
           District district=new District();
           district.setNameRu(districtReq.getNameRu());
           district.setNameUz(districtReq.getNameUz());
           district.setRegion(regionService.findById(districtReq.getRegionId()));
           return districtRepository.save(district);
       }catch (Exception e){
           System.out.println(e);
           return null;
       }
    }

    @Override
    public District edit(Long id, DistrictReq districtReq) {
        try {
            District district=districtRepository.findById(id).get();
            district.setNameRu(districtReq.getNameRu());
            district.setNameUz(districtReq.getNameUz());
            district.setRegion(regionService.findById(districtReq.getRegionId()));
            return districtRepository.save(district);
        }catch (Exception e){
            System.out.println(e);
            return null;
        }
    }

    @Override
    public District findById(Long id) {
       try {
           return districtRepository.findById(id).get();
       }catch (Exception e){
           System.out.println(e);
           return null;
       }
    }

    @Override
    public List<District> findAllByRegionId(Long regionId) {
     try {
         return districtRepository.findAllByRegionId(regionId);
     }catch (Exception e){
         System.out.println(e);
         return new ArrayList<>();
     }
    }

    @Override
    public Result delete(Long id) {
       try {
           districtRepository.deleteById(id);
           return new Result(true,"Successfull deleitng");
       }catch (Exception e){
           System.out.println(e);
           return new Result(false,"No deleting");
       }
    }
}
