package uz.zako.skillrun.service;

import uz.zako.skillrun.entity.Education;
import uz.zako.skillrun.model.Result;

import java.util.List;

public interface EducationService {
    public Education save(Education education);
    public List<Education> findAllByWorkerId(Long workerId);
    public Result delete(Long id);
}
