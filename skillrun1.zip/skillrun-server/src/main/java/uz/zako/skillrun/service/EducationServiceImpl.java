package uz.zako.skillrun.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.zako.skillrun.entity.Education;
import uz.zako.skillrun.model.Result;
import uz.zako.skillrun.repository.EducationRepository;

import java.util.ArrayList;
import java.util.List;

@Service
public class EducationServiceImpl implements EducationService{
    @Autowired
    private EducationRepository educationRepository;
    @Override
    public Education save(Education education) {
        try {
            return educationRepository.save(education);
        }catch (Exception e){
            System.out.println(e);
            return null;
        }
    }

    @Override
    public List<Education> findAllByWorkerId(Long workerId) {
       try {
           return educationRepository.findAllByWorkerId(workerId);
       }catch (Exception e){
           System.out.println(e);
           return new ArrayList<>();
       }
    }

    @Override
    public Result delete(Long id) {
        try {
            educationRepository.deleteById(id);
            return new Result(true,"Successfull deleting");
        }catch (Exception e){
            System.out.println(e);
            return new Result(false,"No deleting");
        }
    }
}
