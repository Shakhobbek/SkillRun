package uz.zako.skillrun.service;

import uz.zako.skillrun.entity.Experience;
import uz.zako.skillrun.model.Result;

import java.util.List;

public interface ExperienceService {
    public Experience save(Experience experience);
    public List<Experience> findAllByWorkerId(Long workerId);
    public Result delete(Long id);

}
