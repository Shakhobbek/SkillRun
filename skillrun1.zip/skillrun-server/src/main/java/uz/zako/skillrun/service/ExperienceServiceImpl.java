package uz.zako.skillrun.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.zako.skillrun.entity.Experience;
import uz.zako.skillrun.model.Result;
import uz.zako.skillrun.repository.ExperienceRepository;

import java.util.ArrayList;
import java.util.List;

@Service
public class ExperienceServiceImpl implements ExperienceService {
    @Autowired
    private ExperienceRepository experienceRepository;

    @Override
    public Experience save(Experience experience) {
       try {
           return experienceRepository.save(experience);
       }catch (Exception e){
           System.out.println(e);
           return null;
       }
    }

    @Override
    public List<Experience> findAllByWorkerId(Long workerId) {
       try {
           return experienceRepository.findAllByWorkerId(workerId);
       }catch (Exception e){
           System.out.println(e);
           return new ArrayList<>();
       }
    }

    @Override
    public Result delete(Long id) {
        try {
            experienceRepository.deleteById(id);
            return new Result(true,"Successfull deleting");
        }catch (Exception e){
            System.out.println(e);
            return new Result(false,"No deleting");
        }
    }
}
