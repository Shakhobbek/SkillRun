package uz.zako.skillrun.service;

import uz.zako.skillrun.entity.LangLevel;
import uz.zako.skillrun.model.Result;
import uz.zako.skillrun.payload.LangLevelReq;

import java.util.List;

public interface LangLevelService {
    public LangLevel save(LangLevelReq langLevelReq);
    public LangLevel edit(Long id,LangLevelReq langLevelReq);
    public List<LangLevel>findAll();
    public Result delete(Long id);
    public List<LangLevel> findAllByLanguageId(Long langId);
}
