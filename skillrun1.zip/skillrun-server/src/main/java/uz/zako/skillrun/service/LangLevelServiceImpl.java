package uz.zako.skillrun.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.zako.skillrun.entity.LangLevel;
import uz.zako.skillrun.entity.Language;
import uz.zako.skillrun.model.Result;
import uz.zako.skillrun.payload.LangLevelReq;
import uz.zako.skillrun.repository.LangLevelRepository;

import java.util.ArrayList;
import java.util.List;

@Service
public class LangLevelServiceImpl implements LangLevelService {
    @Autowired
    private LangLevelRepository langLevelRepository;

    @Autowired
    private LanguageService  languageService;

    @Override
    public LangLevel save(LangLevelReq langLevelReq) {
      try {
          LangLevel langLevel=new LangLevel();
          List<Language> list=new ArrayList<>();
          for (int i = 0; i < langLevelReq.getLanguageIds().size(); i++) {
              list.add(languageService.findById(langLevelReq.getLanguageIds().get(i)));
          }
          langLevel.setLanguages(list);
          langLevel.setNameRu(langLevelReq.getNameRu());
          langLevel.setNameUz(langLevelReq.getNameUz());
          return langLevelRepository.save(langLevel);
      }catch (Exception e){
          System.out.println(e);
          return null;
      }
    }

    @Override
    public LangLevel edit(Long id, LangLevelReq langLevelReq) {
        try {
            LangLevel langLevel=langLevelRepository.findById(id).get();
            List<Language> list=new ArrayList<>();
            for (int i = 0; i < langLevelReq.getLanguageIds().size(); i++) {
                list.add(languageService.findById(langLevelReq.getLanguageIds().get(i)));
            }
            langLevel.setLanguages(list);
            langLevel.setNameRu(langLevelReq.getNameRu());
            langLevel.setNameUz(langLevelReq.getNameUz());
            return langLevelRepository.save(langLevel);
        }catch (Exception e){
            System.out.println(e);
            return null;
        }
    }

    @Override
    public List<LangLevel> findAll() {
       try {
           return langLevelRepository.findAll();
       }catch (Exception e){
           System.out.println(e);
           return new ArrayList<>();
       }
    }

    @Override
    public Result delete(Long id) {
        try {
            langLevelRepository.deleteById(id);
            return new Result(true,"Successfull deleting");
        }catch (Exception e){
            System.out.println(e);
            return new Result(false,"No deleting");
        }
    }

    @Override
    public List<LangLevel> findAllByLanguageId(Long langId) {
        try {
            return langLevelRepository.findAllByLanguageId(langId);
        }catch (Exception e){
            System.out.println(e);
            return new ArrayList<>();
        }
    }
}
