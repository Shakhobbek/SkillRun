package uz.zako.skillrun.service;

import uz.zako.skillrun.entity.Language;
import uz.zako.skillrun.model.Result;

import java.util.List;

public interface LanguageService {
    public Language save(Language language);
    public Language edit(Long id,Language language);
    public List<Language>findAll();
    public Language findById(Long id);
    public Result delete(Long id);
}
