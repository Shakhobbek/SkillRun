package uz.zako.skillrun.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.zako.skillrun.entity.Language;
import uz.zako.skillrun.model.Result;
import uz.zako.skillrun.repository.LanguageRepsitory;

import java.util.ArrayList;
import java.util.List;

@Service
public class LanguageServiceImpl implements LanguageService {
    @Autowired
    private LanguageRepsitory languageRepsitory;

    @Override
    public Language save(Language language) {
        try {
            return languageRepsitory.save(language);
        }catch (Exception e){
            System.out.println(e);
            return null;
        }
    }

    @Override
    public Language edit(Long id, Language language) {
      try {
          Language l=languageRepsitory.findById(id).get();
          l.setNameRu(language.getNameRu());
          l.setNameUz(language.getNameUz());
          return languageRepsitory.save(l);
      }catch (Exception e){
          System.out.println(e);
          return null;
      }
    }

    @Override
    public List<Language> findAll() {
      try {
         return languageRepsitory.findAll();
      }catch (Exception e){
          System.out.println(e);
          return new ArrayList<>();
      }
    }

    @Override
    public Language findById(Long id) {
     try {
         return languageRepsitory.findById(id).get();
     }catch (Exception e){
         System.out.println(e);
         return new Language();
     }
    }

    @Override
    public Result delete(Long id) {
        try {
            languageRepsitory.deleteById(id);
            return new Result(true,"Successfull deleting");
        }catch (Exception e){
            System.out.println(e);
            return new Result(false,"No deleting");
        }
    }
}
