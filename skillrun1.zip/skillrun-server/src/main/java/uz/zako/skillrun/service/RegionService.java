package uz.zako.skillrun.service;

import sun.rmi.runtime.Log;
import uz.zako.skillrun.entity.Region;
import uz.zako.skillrun.model.Result;

import java.util.List;

public interface RegionService {
    public Region save(Region region);
    public Region edit(Long id,Region region);
    public Region findById(Long id);
    public List<Region> findAll();
    public Result delete(Long id);

}
