package uz.zako.skillrun.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.zako.skillrun.entity.Region;
import uz.zako.skillrun.model.Result;
import uz.zako.skillrun.repository.RegionRepository;

import java.util.ArrayList;
import java.util.List;

@Service
public class RegionServiceImpl implements RegionService {
    @Autowired
    private RegionRepository regionRepository;

    @Override
    public Region save(Region region) {
        try {
            return regionRepository.save(region);
        }catch (Exception e){
            System.out.println(e);
            return null;
        }
    }

    @Override
    public Region edit(Long id, Region region) {
        try {
            Region r=regionRepository.findById(id).get();
            r.setNameRu(region.getNameRu());
            r.setNameUz(region.getNameUz());
            return regionRepository.save(r);
        }catch (Exception e){
            System.out.println(e);
            return null;
        }
    }

    @Override
    public Region findById(Long id) {
        try {
            return regionRepository.findById(id).get();
        }catch (Exception e){
            System.out.println(e);
            return null;
        }
    }

    @Override
    public List<Region> findAll() {
      try {
          return regionRepository.findAll();
      }catch (Exception e){
          System.out.println(e);
          return new ArrayList<>();
      }
    }

    @Override
    public Result delete(Long id) {
        try {
            regionRepository.deleteById(id);
            return new Result(true,"Successfull deleting");
        }catch (Exception e){
            System.out.println(e);
            return new Result(false,"No deleting");
        }
    }
}
