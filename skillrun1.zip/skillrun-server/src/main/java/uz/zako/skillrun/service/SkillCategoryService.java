package uz.zako.skillrun.service;

import uz.zako.skillrun.entity.SkillCategory;
import uz.zako.skillrun.model.Result;

import java.util.List;

public interface SkillCategoryService {
  public SkillCategory save(SkillCategory skillCategory);
  public SkillCategory edit(Long id,SkillCategory skillCategory);
  public SkillCategory findById(Long id);
  public List<SkillCategory> findAll();
  public Result delete(Long id);
}
