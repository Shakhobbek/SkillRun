package uz.zako.skillrun.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.zako.skillrun.entity.SkillCategory;
import uz.zako.skillrun.model.Result;
import uz.zako.skillrun.repository.SkillCategoryRepository;
import uz.zako.skillrun.repository.SkillLevelRepository;

import java.util.ArrayList;
import java.util.List;

@Service
public class SkillCategoryServiceImpl implements SkillCategoryService {
    @Autowired
    private SkillCategoryRepository skillCategoryRepository;

    @Override
    public SkillCategory save(SkillCategory skillCategory) {
       try {
          return skillCategoryRepository.save(skillCategory);
       }catch (Exception e){
           System.out.println(e);
           return null;
       }
    }

    @Override
    public SkillCategory findById(Long id) {
        try {
            return skillCategoryRepository.findById(id).get();
        }catch (Exception e){
            System.out.println(e);
            return null;
        }
    }

    @Override
    public SkillCategory edit(Long id, SkillCategory skillCategory) {
        try {
            SkillCategory s=skillCategoryRepository.findById(id).get();
            s.setNameRu(skillCategory.getNameRu());
            s.setNameUz(skillCategory.getNameUz());
            return skillCategoryRepository.save(s);
        }catch (Exception e){
            System.out.println(e);
            return null;
        }
    }

    @Override
    public List<SkillCategory> findAll() {
       try {
           return skillCategoryRepository.findAll();
       }catch (Exception e){
           System.out.println(e);
           return new ArrayList<>();
       }
    }

    @Override
    public Result delete(Long id) {
        try {
            skillCategoryRepository.deleteById(id);
            return new Result(true,"Successfull deleting");
        }catch (Exception e){
            System.out.println(e);
            return new Result(false,"No deleting");
        }

    }
}
