package uz.zako.skillrun.service;

import uz.zako.skillrun.entity.LangLevel;
import uz.zako.skillrun.entity.SkillLevel;
import uz.zako.skillrun.model.Result;
import uz.zako.skillrun.payload.SkillLevelReq;

import java.util.List;

public interface SkillLevelService {
    public SkillLevel save(SkillLevelReq req);
    public SkillLevel edit(Long id,SkillLevelReq req);
    public List<SkillLevel> findAllBySkillSubCategorieId(Long categorieId);
    public SkillLevel findById(Long id);
    public Result delete(Long id);
}
