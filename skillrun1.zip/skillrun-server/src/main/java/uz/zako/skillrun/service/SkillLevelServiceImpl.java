package uz.zako.skillrun.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.zako.skillrun.entity.LangLevel;
import uz.zako.skillrun.entity.SkillLevel;
import uz.zako.skillrun.entity.SkillSubCategory;
import uz.zako.skillrun.model.Result;
import uz.zako.skillrun.payload.SkillLevelReq;
import uz.zako.skillrun.repository.SkillLevelRepository;

import java.util.ArrayList;
import java.util.List;

@Service
public class SkillLevelServiceImpl implements SkillLevelService {
    @Autowired
    private SkillLevelRepository skillLevelRepository;

    @Autowired
    private SkillSubCategoryService skillSubCategoryService;

    @Override
    public SkillLevel save(SkillLevelReq req) {
        try {
            SkillLevel skillLevel=new SkillLevel();
            List<SkillSubCategory> list=new ArrayList<>();
            for (int i = 0; i < req.getSkillSubCategorieIds().size(); i++) {
                list.add(skillSubCategoryService.findById(req.getSkillSubCategorieIds().get(i)));
            }
            skillLevel.setNameUz(req.getNameUz());
            skillLevel.setNameRu(req.getNameRu());
            skillLevel.setSkillSubCategories(list);
            return skillLevelRepository.save(skillLevel);
        }catch (Exception e){
            System.out.println(e);
            return null;
        }
    }

    @Override
    public SkillLevel edit(Long id, SkillLevelReq req) {
        try {
            SkillLevel skillLevel=skillLevelRepository.findById(id).get();
            List<SkillSubCategory> list=new ArrayList<>();
            for (int i = 0; i < req.getSkillSubCategorieIds().size(); i++) {
                list.add(skillSubCategoryService.findById(req.getSkillSubCategorieIds().get(i)));
            }
            skillLevel.setNameUz(req.getNameUz());
            skillLevel.setNameRu(req.getNameRu());
            skillLevel.setSkillSubCategories(list);
            return skillLevelRepository.save(skillLevel);
        }catch (Exception e){
            System.out.println(e);
            return null;
        }
    }

    @Override
    public List<SkillLevel> findAllBySkillSubCategorieId(Long categorieId) {
       try {
           return skillLevelRepository.findAllBySkillSubCategorieId(categorieId);
       }catch (Exception e){
           System.out.println(e);
           return new ArrayList<>();
       }
    }

    @Override
    public SkillLevel findById(Long id) {
       try {
           return skillLevelRepository.findById(id).get();
       }catch (Exception e){
           System.out.println(e);
           return null;
       }
    }

    @Override
    public Result delete(Long id) {
        try {
            skillLevelRepository.deleteById(id);
            return new Result(true,"Successfull deleting");
        }catch (Exception e){
            System.out.println(e);
            return new Result(false,"No deleting");
        }
    }
}
