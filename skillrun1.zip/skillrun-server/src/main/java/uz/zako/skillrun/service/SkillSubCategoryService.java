package uz.zako.skillrun.service;

import uz.zako.skillrun.entity.SkillSubCategory;
import uz.zako.skillrun.model.Result;
import uz.zako.skillrun.payload.SkillSubCategoryReq;

import java.util.List;

public interface SkillSubCategoryService {
    public SkillSubCategory save(SkillSubCategoryReq req);
    public SkillSubCategory edit(Long id,SkillSubCategoryReq req);
    public SkillSubCategory findById(Long id);

    public List<SkillSubCategory> findAllBySkillCategoryId(Long skillCategoryId);
    public Result delete(Long id);
}
