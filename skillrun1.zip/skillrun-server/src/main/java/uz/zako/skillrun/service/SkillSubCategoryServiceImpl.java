package uz.zako.skillrun.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.zako.skillrun.entity.SkillSubCategory;
import uz.zako.skillrun.model.Result;
import uz.zako.skillrun.payload.SkillSubCategoryReq;
import uz.zako.skillrun.repository.SkillSubcategoryRepository;

import java.util.ArrayList;
import java.util.List;

@Service
public class SkillSubCategoryServiceImpl  implements SkillSubCategoryService{
    @Autowired
    private SkillSubcategoryRepository skillSubcategoryRepository;

    @Autowired
    private SkillCategoryService skillCategoryService;

    @Override
    public SkillSubCategory save(SkillSubCategoryReq req) {
       try {
           SkillSubCategory subCategory=new SkillSubCategory();
           subCategory.setNameRu(req.getNameRu());
           subCategory.setNameUz(req.getNameUz());
           subCategory.setSkillCategory(skillCategoryService.findById(req.getSkillCategoryId()));
           return skillSubcategoryRepository.save(subCategory);
       }catch (Exception e){
           System.out.println(e);
           return null;
       }
    }

    @Override
    public SkillSubCategory edit(Long id, SkillSubCategoryReq req) {
        try {
            SkillSubCategory subCategory=skillSubcategoryRepository.findById(id).get();
            subCategory.setNameRu(req.getNameRu());
            subCategory.setNameUz(req.getNameUz());
            subCategory.setSkillCategory(skillCategoryService.findById(req.getSkillCategoryId()));
            return skillSubcategoryRepository.save(subCategory);
        }catch (Exception e){
            System.out.println(e);
            return null;
        }
    }

    @Override
    public List<SkillSubCategory> findAllBySkillCategoryId(Long skillCategoryId) {
       try {
           return skillSubcategoryRepository.findAllBySkillCategoryId(skillCategoryId);
       }catch (Exception e){
           System.out.println(e);
           return new ArrayList<>();
       }
    }

    @Override
    public SkillSubCategory findById(Long id) {
        try {
            return skillSubcategoryRepository.findById(id).get();
        }catch (Exception e){
            return null;
        }
    }

    @Override
    public Result delete(Long id) {
        try {
            skillSubcategoryRepository.deleteById(id);
            return new Result(true,"Successfull deleting");
        }catch (Exception e){
            System.out.println(e);
            return new Result(false,"No deleting");
        }
    }
}
