package uz.zako.skillrun.service;

import org.springframework.http.ResponseEntity;
import uz.zako.skillrun.entity.User;
import uz.zako.skillrun.model.JwtResponse;
import uz.zako.skillrun.model.Result;
import uz.zako.skillrun.payload.LoginReq;
import uz.zako.skillrun.payload.ProfilSettings;

import java.util.List;


public interface UserService {
    public Result editPassword(ProfilSettings profilSettings, User user);
    public ResponseEntity<JwtResponse> signin(LoginReq loginRequest);
    public User save(User user);
}
