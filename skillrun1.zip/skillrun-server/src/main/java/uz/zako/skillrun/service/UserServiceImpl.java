package uz.zako.skillrun.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import uz.zako.skillrun.entity.User;
import uz.zako.skillrun.model.JwtProvider;
import uz.zako.skillrun.model.JwtResponse;
import uz.zako.skillrun.model.Result;
import uz.zako.skillrun.payload.LoginReq;
import uz.zako.skillrun.payload.ProfilSettings;
import uz.zako.skillrun.repository.RoleRepository;
import uz.zako.skillrun.repository.UserRepository;

import java.util.ArrayList;
import java.util.List;


@Service
public class UserServiceImpl implements UserService {
    @Autowired
    AuthenticationManager authenticationManager;
    @Autowired
    JwtProvider jwtProvider;
    @Autowired
    UserRepository userRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private RoleRepository roleRepository;



    @Override
    public Result editPassword(ProfilSettings profilSettings, User user) {
        if (signin(new LoginReq(user.getUsername(),profilSettings.getOld_password())).getBody().getToken()!=null){
            user.setPassword(passwordEncoder.encode(profilSettings.getNew_password()));
           if ( userRepository.save(user)!=null){
               return new Result(true,"Parol o'zgardi");
           }
        }
        return new Result(false,"Parol o'zgarmadi");
    }

    @Override
    public ResponseEntity<JwtResponse> signin(LoginReq loginRequest) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        loginRequest.getUsername(),
                        loginRequest.getPassword()
                )
        );
        SecurityContextHolder.getContext().setAuthentication(authentication);
        String jwt = jwtProvider.generateJwtToken(authentication);
        return ResponseEntity.ok(new JwtResponse(jwt));
    }

    @Override
    public User save(User user) {
        try{
            return userRepository.save(user);
        }catch (Exception e){
            System.out.println(e);
            return null;
        }
    }
}
