package uz.zako.skillrun.service;

import uz.zako.skillrun.entity.Worker;
import uz.zako.skillrun.model.Result;
import uz.zako.skillrun.payload.WorkerReq;
import uz.zako.skillrun.payload.WorkerRes;

public interface WorkerService {
public Worker save(WorkerReq workerReq);
public Worker edit(Long id,WorkerReq workerReq);
public Worker findById(Long id);
public WorkerRes getWorker(Long id);

public Result delete(Long id);
}
