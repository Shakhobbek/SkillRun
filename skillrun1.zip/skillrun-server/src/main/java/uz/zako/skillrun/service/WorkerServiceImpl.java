package uz.zako.skillrun.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.zako.skillrun.entity.Role;
import uz.zako.skillrun.entity.Worker;
import uz.zako.skillrun.model.Result;
import uz.zako.skillrun.payload.WorkerReq;
import uz.zako.skillrun.payload.WorkerRes;
import uz.zako.skillrun.repository.RoleRepository;
import uz.zako.skillrun.repository.WorkerRepository;

import java.util.ArrayList;
import java.util.List;

@Service
public class WorkerServiceImpl implements WorkerService {
    @Autowired
    private WorkerRepository workerRepository;

    @Autowired
    private DistrictService districtService;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private AttachmentService attachmentService;

    @Override
    public Worker save(WorkerReq workerReq) {
        try {
            Worker worker=new Worker();
            worker.setDistrict(districtService.findById(workerReq.getDistrictId()));
            worker.setLanguage_languageLevel(workerReq.getLanguage_languageLevel());
            worker.setSkill_subcategory_level(workerReq.getSkill_subcategory());
            worker.setPassword(workerReq.getPassword());
            worker.setBirthday(workerReq.getBirthday());
            worker.setFirstname(workerReq.getFirstname());
            worker.setLastname(workerReq.getLastname());
            worker.setUsername(workerReq.getEmail());
            List<Role> roles=new ArrayList<>();
            roles.add((roleRepository.findByName("ROLE_USER")));
            worker.setRoles(roles);
            worker.setPhotoAvatar(attachmentService.findById(workerReq.getPhotoAvatarId()));
            return workerRepository.save(worker);
        }catch (Exception e){
            System.out.println(e);
            return null;
        }
    }

    @Override
    public Worker edit(Long id, WorkerReq workerReq) {
        try {
            Worker worker=workerRepository.findById(id).get();
            worker.setDistrict(districtService.findById(workerReq.getDistrictId()));
            worker.setLanguage_languageLevel(workerReq.getLanguage_languageLevel());
            worker.setSkill_subcategory_level(workerReq.getSkill_subcategory());
            worker.setPassword(workerReq.getPassword());
            worker.setBirthday(workerReq.getBirthday());
            worker.setFirstname(workerReq.getFirstname());
            worker.setLastname(workerReq.getLastname());
            worker.setUsername(workerReq.getEmail());
            List<Role> roles=new ArrayList<>();
            roles.add((roleRepository.findByName("ROLE_USER")));
            worker.setRoles(roles);
            worker.setPhotoAvatar(attachmentService.findById(workerReq.getPhotoAvatarId()));
            return workerRepository.save(worker);
        }catch (Exception e){
            System.out.println(e);
            return null;
        }
    }

    @Override
    public Worker findById(Long id) {
       try {
           return workerRepository.findById(id).get();
       }catch (Exception e){
           System.out.println(e);
           return null;
       }
    }

    @Override
    public WorkerRes getWorker(Long id) {
        return null;
    }

    @Override
    public Result delete(Long id) {
        try {
            workerRepository.deleteById(id);
            return new Result(true,"Successfull deleitng");
        }catch (Exception e){
            System.out.println(e);
            return new Result(false,"No deleting");
        }
    }
}
